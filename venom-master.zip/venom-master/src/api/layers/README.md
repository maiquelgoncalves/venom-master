# Layers

## Each layer should extends the previous one in the next order

1. Host layer
2. Profile layer
3. Listener layer
4. Sender layer
5. Retriever layer
6. Group layer
7. Controls layer
8. Business layer (Optional)

**Controls layer** should be enough
