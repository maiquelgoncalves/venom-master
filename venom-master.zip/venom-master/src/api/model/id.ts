export interface Id {
  server: string;
  user: string;
  _serialized: string;
  fromMe: boolean;
  remote: string;
  id: string;
}
