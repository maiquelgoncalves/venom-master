export enum GroupNotificationType {
  Add = 'add',
  Inivite = 'invite',
  Remove = 'remove',
  Leave = 'leave',
  Subject = 'subject',
  Description = 'description',
  Picture = 'picture',
  Announce = 'announce',
  Restrict = 'restrict'
}
