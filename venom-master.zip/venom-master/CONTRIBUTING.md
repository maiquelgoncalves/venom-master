# Contributing

PRs are welcome. Just please mantain the code as clean as possible and use common JS conventions
